/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package art_with_a_heart;

/**
 *
 * @author Rasheed
 */
import addPanels.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class AwaH_GUI {

    private JPanel contentPane;

    private addAvailabilityPanel availibilityPanel;
    private addClassPanel classPanel;
    private addEventPanel eventPanel;
    private addLocationPanel locationPanel;
    private addProjectPanel projectPanel;
    private addPublic_ArtPanel public_artPanel;
    private addStorePanel storePanel;
    private addUserPanel userPanel;
    private addVolunteerPanel volunteerPanel;

    private addBirthdayPanel birthdayPanel;
    private addWorkAnn workAnn;

    public AwaH_GUI() {

    }

    private void displayGUI() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        JFrame frame = new JFrame("Art With a Heart Database System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        contentPane = new JPanel();
        contentPane.setBorder(
                BorderFactory.createEmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(new CardLayout());

        initNavigationMenu(frame);

        //Menu 1
        availibilityPanel = new addAvailabilityPanel();
        classPanel = new addClassPanel();
        eventPanel = new addEventPanel();
        locationPanel = new addLocationPanel();
        projectPanel = new addProjectPanel();
        public_artPanel = new addPublic_ArtPanel();
        storePanel = new addStorePanel();
        userPanel = new addUserPanel();
        volunteerPanel = new addVolunteerPanel();

        contentPane.add(availibilityPanel, "addAvailabilityPanel");
        contentPane.add(classPanel, "addClassPanel");
        contentPane.add(eventPanel, "addEventPanel");
        contentPane.add(locationPanel, "addLocationPanel");
        contentPane.add(projectPanel, "addProjectPanel");
        contentPane.add(public_artPanel, "addPublic_ArtPanel");
        contentPane.add(storePanel, "addStorePanel");
        contentPane.add(userPanel, "addUserPanel");
        contentPane.add(volunteerPanel, "addVolunteerPanel");

        //Menu 2
        birthdayPanel = new addBirthdayPanel();
        workAnn = new addWorkAnn();
        
        contentPane.add(birthdayPanel, "addBirthdayPanel");
        contentPane.add(workAnn, "addWorkAnn");
        

        frame.getContentPane().add(contentPane, BorderLayout.CENTER);
        frame.pack();
        //frame.setLocationByPlatform(true);
        frame.setLocationRelativeTo(null);
        frame.setSize(810, 600);
        frame.setVisible(true);
    }

    private void initNavigationMenu(JFrame f) {
        //Navigation Menu
        JMenuBar menuBar = new JMenuBar();
        JMenu menu = new JMenu("Database Menu");
        menuBar.add(menu);

        JMenuItem addAvailability = new JMenuItem(new AbstractAction("Availability..") {
            public void actionPerformed(ActionEvent e) {
                String changeToPanel = "addAvailabilityPanel";
                CardLayout cardLayout = (CardLayout) contentPane.getLayout();
                cardLayout.show(contentPane, changeToPanel);
            }
        });
        menu.add(addAvailability);
        menu.addSeparator();

        JMenuItem addClass = new JMenuItem(new AbstractAction("Class..") {
            public void actionPerformed(ActionEvent e) {
                String changeToPanel = "addClassPanel";
                CardLayout cardLayout = (CardLayout) contentPane.getLayout();
                cardLayout.show(contentPane, changeToPanel);
            }
        });
        menu.add(addClass);
        menu.addSeparator();

        JMenuItem addEvent = new JMenuItem(new AbstractAction("Event..") {
            public void actionPerformed(ActionEvent e) {
                String changeToPanel = "addEventPanel";
                CardLayout cardLayout = (CardLayout) contentPane.getLayout();
                cardLayout.show(contentPane, changeToPanel);
            }
        });
        menu.add(addEvent);
        menu.addSeparator();

        JMenuItem addLocation = new JMenuItem(new AbstractAction("Location..") {
            public void actionPerformed(ActionEvent e) {
                String changeToPanel = "addLocationPanel";
                CardLayout cardLayout = (CardLayout) contentPane.getLayout();
                cardLayout.show(contentPane, changeToPanel);
            }
        });
        menu.add(addLocation);
        menu.addSeparator();

        JMenuItem addProject = new JMenuItem(new AbstractAction("Project..") {
            public void actionPerformed(ActionEvent e) {
                String changeToPanel = "addProjectPanel";
                CardLayout cardLayout = (CardLayout) contentPane.getLayout();
                cardLayout.show(contentPane, changeToPanel);
            }
        });
        menu.add(addProject);
        menu.addSeparator();

        JMenuItem addPublic_Art = new JMenuItem(new AbstractAction("Public Art..") {
            public void actionPerformed(ActionEvent e) {
                String changeToPanel = "addPublic_ArtPanel";
                CardLayout cardLayout = (CardLayout) contentPane.getLayout();
                cardLayout.show(contentPane, changeToPanel);
            }
        });
        menu.add(addPublic_Art);
        menu.addSeparator();

        JMenuItem addStore = new JMenuItem(new AbstractAction("Store..") {
            public void actionPerformed(ActionEvent e) {
                String changeToPanel = "addStorePanel";
                CardLayout cardLayout = (CardLayout) contentPane.getLayout();
                cardLayout.show(contentPane, changeToPanel);
            }
        });
        menu.add(addStore);
        menu.addSeparator();

        JMenuItem addUser = new JMenuItem(new AbstractAction("User..") {
            public void actionPerformed(ActionEvent e) {
                String changeToPanel = "addUserPanel";
                CardLayout cardLayout = (CardLayout) contentPane.getLayout();
                cardLayout.show(contentPane, changeToPanel);
            }
        });
        menu.add(addUser);
        menu.addSeparator();

        JMenuItem addVolunteer = new JMenuItem(new AbstractAction("Volunteer..") {
            public void actionPerformed(ActionEvent e) {
                String changeToPanel = "addVolunteerPanel";
                CardLayout cardLayout = (CardLayout) contentPane.getLayout();
                cardLayout.show(contentPane, changeToPanel);
            }
        });
        menu.add(addVolunteer);
        menu.addSeparator();

        JMenu menu2 = new JMenu("Special");
        
        JMenuItem getBirthdays = new JMenuItem(new AbstractAction("Birthdays!") {
            public void actionPerformed(ActionEvent e) {
                String changeToPanel = "addBirthdayPanel";
                CardLayout cardLayout = (CardLayout) contentPane.getLayout();
                cardLayout.show(contentPane, changeToPanel);
            }
        });
        menu2.add(getBirthdays);
        menu.addSeparator();
        
        JMenuItem getWorkAnn = new JMenuItem(new AbstractAction("Workerversaries!") {
            public void actionPerformed(ActionEvent e) {
                String changeToPanel = "addWorkAnn";
                CardLayout cardLayout = (CardLayout) contentPane.getLayout();
                cardLayout.show(contentPane, changeToPanel);
            }
        });
        menu2.add(getWorkAnn);
        menuBar.add(menu2);

        f.setJMenuBar(menuBar);
    }

    public void run() {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    new AwaH_GUI().displayGUI();
                } catch (ClassNotFoundException
                        | InstantiationException
                        | IllegalAccessException
                        | SQLException ex) {
                    Logger.getLogger(AwaH_GUI.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }
}
