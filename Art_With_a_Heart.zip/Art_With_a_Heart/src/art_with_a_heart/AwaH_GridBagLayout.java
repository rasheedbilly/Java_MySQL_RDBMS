/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package art_with_a_heart;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.*;

/**
 *
 * @author Rasheed
 */
public class AwaH_GridBagLayout {

    static JMenuBar add_menuBar, select_menuBar;

    public AwaH_GridBagLayout() {
    }

    public void launch() {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }

    private static void addComponentsToPane(Container pane) {

        pane.setLayout(new GridBagLayout());
        GridBagConstraints gBC = new GridBagConstraints();
        gBC.fill = GridBagConstraints.HORIZONTAL;
        gBC.insets = new Insets(10, 0, 0, 0);  //Padding

        //Navigation Menu
        add_menuBar = new JMenuBar();
        JMenu menu = new JMenu("Add to Database");
        menu.setMnemonic(KeyEvent.VK_A);
        menu.getAccessibleContext().setAccessibleDescription(
                "The only menu in this program that has menu items");
        add_menuBar.add(menu);
        JMenuItem addVolunteer = new JMenuItem(new AbstractAction("Add Volunteer") {
            public void actionPerformed(ActionEvent e) {
                System.out.println("Boobs");
            }
        });
//        JMenuItem addVolunteer = new JMenuItem("Add Volunteer",
//                KeyEvent.VK_T);
//        menuItem.setAccelerator(KeyStroke.getKeyStroke(
//                KeyEvent.VK_1, ActionEvent.ALT_MASK));
//        menuItem.getAccessibleContext().setAccessibleDescription(
//                "This doesn't really do anything");
        menu.add(addVolunteer);
        menu.addSeparator();

        JMenuItem addAvailability = new JMenuItem("Add Availability...");
        menu.add(addAvailability);
        menu.addSeparator();

        JMenuItem addClass = new JMenuItem("Add Class...");
        menu.add(addClass);
        menu.addSeparator();

        JMenuItem addEvent = new JMenuItem("Add Event...");
        menu.add(addEvent);
        menu.addSeparator();

        JMenuItem addLocation = new JMenuItem("Add Location...");
        menu.add(addLocation);
        menu.addSeparator();

        JMenuItem addProject = new JMenuItem("Add Project...");
        menu.add(addProject);
        menu.addSeparator();

        JMenuItem addPublic_Art = new JMenuItem("Add Public Art...");
        menu.add(addPublic_Art);
        menu.addSeparator();

        JMenuItem addStore = new JMenuItem("Add Store...");
        menu.add(addProject);

        //Custom Query
        JTextField customQuery = new JTextField("Custom Query");
        customQuery.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                customQuery.setText("");
            }
        });
        gBC.gridx = 0;
        gBC.gridy = 0;
        gBC.gridwidth = 3;
        customQuery.setEditable(true);
        pane.add(customQuery, gBC);

        //Birthdays and Workversaries
        JTextField startDate = new JTextField("Start Date");
        startDate.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                startDate.setText("");
            }
        });
        gBC.gridx = 0;
        gBC.gridy = 1;
        gBC.gridwidth = 1;
        customQuery.setEditable(true);
        pane.add(startDate, gBC);

        JTextField endDate = new JTextField("End Date");
        endDate.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                endDate.setText("");
            }
        });
        gBC.gridx = 1;
        gBC.gridy = 1;
        gBC.gridwidth = 1;
        customQuery.setEditable(true);
        pane.add(endDate, gBC);

        JComboBox jcmbSample = new JComboBox(new String[]{"Select..", "Birthdays", "Work-Anniversaries"});
        gBC.gridx = 2;
        gBC.gridy = 1;
        gBC.gridwidth = 1;
        //gBC.ipady = 0;
        //gBC.weighty = 1.0;
        //gBC.anchor = GridBagConstraints.PAGE_END;
        pane.add(jcmbSample, gBC);

        //Submit
        JButton jbnButton = new JButton("Submit");
        gBC.ipady = 40; //This component has more breadth compared to other buttons
        gBC.weightx = 0.0;
        gBC.gridwidth = 3;
        gBC.gridx = 0;
        gBC.gridy = 2;
        pane.add(jbnButton, gBC);

        //Output
        JTextField output = new JTextField("");
        startDate.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                startDate.setText("");
            }
        });
        gBC.gridx = 0;
        gBC.gridy = 3;
        gBC.gridwidth = 3;
        gBC.gridheight = 9;
        customQuery.setEditable(false);
        pane.add(output, gBC);

    }

    private static void createAndShowGUI() {

        JFrame.setDefaultLookAndFeelDecorated(true);
        JFrame frame = new JFrame("Art with a Heart Volunteer System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Set up the content pane.
        addComponentsToPane(frame.getContentPane());
        frame.setJMenuBar(add_menuBar);

        frame.pack();
        frame.setVisible(true);
    }

}
