/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package art_with_a_heart;

/**
 *
 * @author Rasheed
 * SET GLOBAL time_zone = '-1:00';
 */
public class Main {

//    static Connection connection = null;
//    static String databaseName = "AWAH_test";
//    static String url = "jdbc:mysql://localhost:3306/" + databaseName;
//
//    static String username = "root";
//    static String password = "Keep0utg";
//    
//    static ResultSet rs;
//    static Statement stmt;

    public static void main(String[] args) {
        //AwaH_GridBagLayout gui = new AwaH_GridBagLayout();
        //gui.launch();
        
        AwaH_GUI gg = new AwaH_GUI();
        gg.run();
        
//        try {
//            Database.init();
//            Database.getAllFromTable("Volunteer");
//            Database.connection.close();
//        } catch (ClassNotFoundException ex) {
//            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
//        } catch (SQLException ex) {
//            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        
    }
    

    

    
    public void getBirthdays(String d1, String d2){
        
    }
    
    public void getWorkAnniversary(String d1, String d2){
        
    }
}
