/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package art_with_a_heart;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JTable;

/**
 *
 * @author Rasheed DELETE FROM Availability WHERE A_Id = 9;
 */
public class Database {

    public static Connection connection = null;
    static String databaseName = "AWAH_test";
    static String url = "jdbc:mysql://localhost:3306/" + databaseName;

    static String username = "root";
    static String password = "Keep0utg";

    static ResultSet rs;
    static Statement stmt;

    static JTable Availability;

    public static void init() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
        connection = DriverManager.getConnection(url, username, password);
        stmt = connection.createStatement();

    }

    public static void runQuery(String q) throws SQLException {
        stmt.executeUpdate(q);
    }

    public static String returnAllRows(String table) throws SQLException {
        rs = stmt.executeQuery("SELECT * FROM " + table);
        ResultSetMetaData rsmd = rs.getMetaData();
        String t = "";
        while (rs.next()) {
            //String lastName = rs.getString("Lname");
            for (int i = 1; i <= rsmd.getColumnCount(); i++) {
                t += rs.getString(i);
                if (i <= rsmd.getColumnCount() - 1) {
                    t += "|";
                }
            }
            t += "\n";
        }
        return t;
    }
    
    public static String returnMonthNumber(String m){
        String s = "";
        switch(m.toUpperCase()){
            case "JAN": s = "01"; break;
            case "FEB": s = "02"; break;
            case "MAR": s = "03"; break;
            case "APR": s = "04"; break;
            case "MAY": s = "05"; break;
            case "JUN": s = "06"; break;
            case "JUL": s = "07"; break;
            case "AUG": s = "08"; break;
            case "SEP": s = "09"; break;
            case "OCT": s = "10"; break;
            case "NOV": s = "11"; break;
            case "DEC": s = "12"; break;
        }
        return s;
    }

//    public static Object[][] returnAvailTable2D() throws SQLException {
//        rs = stmt.executeQuery("SELECT * FROM Availability");
//        ResultSetMetaData rsmd = rs.getMetaData();
//
//        String[] colName = {"A_Id", "Day", "Start_Time", "End_Time", "Volunteer_Id"};
//        ArrayList<String> rows = new ArrayList();
//        String t = "";
//        while (rs.next()) { //rs.getString(i)
//            for (int i = 1; i <= rsmd.getColumnCount(); i++) {
//                t += rs.getString(i);
//                if (i <= rsmd.getColumnCount() - 1) {
//                    t += "|";
//                }
//            }
//            rows.add(t);
//            t = "";
//        }
//        //Availability = new JTable(listTo2d(rows), colName);
//        return listTo2d(rows);
//    }


//    public static String[][] listTo2d(ArrayList<String> rows) {
//        //String[][] data = new String[rows.get(0).length][rows.size()];
//        String[][] data = new String[rows.size()][rows.get(0).split("|").length];
//        for (int i = 0; i < rows.size(); i++) {
//            for (int j = 0; j < rows.get(0).split("|").length; j++) {
//                data[i][j] = rows.get(i).split("|")[j];
//            }
//        }
//        return data;
//    }

    public static void getAllFromTable(String table) throws SQLException {
        rs = stmt.executeQuery("SELECT * FROM " + table);
        ResultSetMetaData rsmd = rs.getMetaData();
        System.out.println(table + " Table");
        while (rs.next()) {
            //String lastName = rs.getString("Lname");
            for (int i = 1; i <= rsmd.getColumnCount(); i++) {
                System.out.print(rs.getString(i) + " | ");
            }
            System.out.println();
        }
    }

//    public static void getVolunteer(int ID) throws SQLException {
//        rs = stmt.executeQuery("SELECT * FROM Volunteer WHERE V_Id = " + String.valueOf(ID));
//        ResultSetMetaData rsmd = rs.getMetaData();
//        while (rs.next()) {
//            //String lastName = rs.getString("Lname");
//            for (int i = 1; i <= rsmd.getColumnCount(); i++) {
//                System.out.print(rs.getString(i) + " | ");
//            }
//            System.out.println();
//        }
//    }
}
