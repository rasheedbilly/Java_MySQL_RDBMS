/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package addPanels;

import art_with_a_heart.Database;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author Rasheed
 */
public class addPublic_ArtPanel extends JPanel {

    String data;
    JTextArea table;

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        try {
            g.drawImage(ImageIO.read(new File("res/background1.jpg")), 0, 0, null);
            g.drawImage(ImageIO.read(new File("res/AwaH_Logo.png")), 0, 0, null);
        } catch (IOException ex) {
        }
    }

    public addPublic_ArtPanel() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        //construct components
        JLabel title = new JLabel("Public Art");
        CustomPanel.header1(title);
        title.setSize(100, 30);
        c.anchor = GridBagConstraints.PAGE_START;
        c.gridx = 1;
        c.gridy = 0;
        add(title, c);

        //artName
        JTextField artName = new JTextField("Art Name");
        artName.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                artName.setText("");
            }
        });
        artName.setEditable(true);
        JLabel artNameLabel = new JLabel("Art Name", JLabel.TRAILING);
        CustomPanel.header2(artNameLabel);
        artNameLabel.setLabelFor(artName);
        c.anchor = GridBagConstraints.FIRST_LINE_START;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 1;
        add(artNameLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 1;
        add(artName, c);

        //artist
        JTextField artist = new JTextField("Artist");
        artist.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                artist.setText("");
            }
        });
        artist.setEditable(true);
        JLabel artistLabel = new JLabel("Artist Name", JLabel.TRAILING);
        CustomPanel.header2(artistLabel);
        artistLabel.setLabelFor(artName);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 2;
        add(artistLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 2;
        add(artist, c);

        //community
        JTextField community = new JTextField("Community");
        community.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                community.setText("");
            }
        });
        community.setEditable(true);
        JLabel communityLabel = new JLabel("Community Label", JLabel.TRAILING);
        CustomPanel.header2(communityLabel);
        communityLabel.setLabelFor(community);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 3;
        add(communityLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 3;
        add(community, c);

        //locationId
        JTextField locationId = new JTextField("location ID");
        locationId.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                locationId.setText("");
            }
        });
        locationId.setEditable(true);
        JLabel locationIdLabel = new JLabel("Location ID", JLabel.TRAILING);
        CustomPanel.header2(locationIdLabel);
        locationIdLabel.setLabelFor(locationId);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 4;
        add(locationIdLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 4;
        add(locationId, c);

        //Submit
        JButton addButton = new JButton("Add Public Art");
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Database.init();
                    String artName_s = artName.getText();
                    String artist_s = artist.getText();
                    String community_s = community.getText();
                    String locationId_s = locationId.getText();
                    Database.runQuery("INSERT INTO Public_Art (Art_Name, Artist, Community, Location_Id) "
                            + "VALUES (\"" + artName_s + "\", \""
                            + artist_s + "\", \""
                            + community_s + "\", \""
                            + locationId_s + "\");");
                    Database.connection.close();
                } catch (ClassNotFoundException
                        | InstantiationException
                        | IllegalAccessException
                        | SQLException ex) {
                }

            }
        });
        c.gridx = 1;
        c.gridy = 5;
        c.gridwidth = 2;
        add(addButton, c);

        //Delete Entry
        JLabel deleteLabel = new JLabel("Delete Entry", JLabel.TRAILING);
        CustomPanel.header2(deleteLabel);
        JTextField deleteField = new JTextField("Row ID");
        deleteLabel.setLabelFor(deleteField);
        JButton deleteButton = new JButton("Delete");
        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Database.init();
                    String A_Id = deleteField.getText();
                    Database.runQuery("DELETE FROM Public_Art WHERE PA_Id = "
                            + A_Id + ";");
                } catch (ClassNotFoundException
                        | InstantiationException
                        | IllegalAccessException
                        | SQLException ex) {
                }

            }
        });
        c.gridx = 0;
        c.gridy = 6;
        c.gridwidth = 1;
        add(deleteLabel, c);
        c.gridx = 1;
        c.gridy = 6;
        add(deleteField, c);
        c.gridx = 2;
        c.gridy = 6;
        add(deleteButton, c);

        //Refresh
        JButton refreshTable = new JButton("Refresh Table");
        refreshTable.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Database.init();
                    setData(Database.returnAllRows(data));
                    table.setText(data);
                    add(table, c);
                    //Database.connection.close();
                } catch (ClassNotFoundException
                        | InstantiationException
                        | IllegalAccessException
                        | SQLException ex) {
                }

            }
        });
        c.gridx = 1;
        c.gridy = 7;
        //add(refreshTable, c);

        //Show Table
        Database.init();
        data = Database.returnAllRows("Public_Art");
        table = new JTextArea();
        table.setEditable(false);
        table.setText(data);
        c.gridwidth = 3;
        c.gridx = 0;
        c.gridy = 8;
        add(table, c);
    }

    public void setData(String data) {
        this.data = data;
    }
}
