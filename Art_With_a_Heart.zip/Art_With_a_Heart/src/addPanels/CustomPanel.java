/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package addPanels;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;

/**
 *
 * @author Rasheed
 */
public class CustomPanel {

    protected static void header1(JLabel jl) {
        jl.setOpaque(true);
        jl.setBackground(Color.DARK_GRAY);
        jl.setForeground(Color.WHITE);
        jl.setFont(new Font("Monospaced", Font.BOLD, 20));
    }

    protected static void header2(JLabel jl) {
        jl.setOpaque(true);
        jl.setBackground(Color.DARK_GRAY);
        jl.setForeground(Color.WHITE);
        jl.setFont(new Font("Monospaced", Font.BOLD, 16));
    }

}
