/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package addPanels;

import art_with_a_heart.Database;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.SpinnerDateModel;
import javax.swing.text.DateFormatter;

/**
 *
 * @author Rasheed
 * SELECT * FROM Volunteer WHERE Start_Date BETWEEN '2020-01-01' AND DATE_ADD('2021-01-01',INTERVAL 1 DAY)
 */
public class addWorkAnn extends JPanel {

    String data;
    JTextArea table;

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        try {
            g.drawImage(ImageIO.read(new File("res/background1.jpg")), 0, 0, null);
        } catch (IOException ex) {
        }
    }

    public addWorkAnn() {
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        //construct components
        JLabel title = new JLabel("Workerversaries");
        CustomPanel.header1(title);
        c.anchor = GridBagConstraints.PAGE_START;
        c.gridx = 1;
        c.gridy = 0;
        add(title, c);

        //Start Date
        SpinnerDateModel startDateModel = new SpinnerDateModel();
        //dateModel.setValue(calendar.getTime());
        JSpinner startDateSpinner = new JSpinner(startDateModel);
        JSpinner.DateEditor startDateEditor = new JSpinner.DateEditor(startDateSpinner, "YYYY:MM:dd");
        DateFormatter startDateFormatter = (DateFormatter) startDateEditor.getTextField().getFormatter();
        startDateFormatter.setAllowsInvalid(false); // this makes what you want
        startDateFormatter.setOverwriteMode(true);
        startDateSpinner.setEditor(startDateEditor);
        JLabel startDateLabel = new JLabel("Begining Date", JLabel.TRAILING);
        CustomPanel.header2(startDateLabel);
        startDateLabel.setLabelFor(startDateSpinner);
        c.anchor = GridBagConstraints.FIRST_LINE_START;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 1;
        add(startDateLabel, c);
        c.gridx = 1;
        c.gridy = 1;
        add(startDateSpinner, c);

        //End Date
        SpinnerDateModel endDateModel = new SpinnerDateModel();
        //dateModel.setValue(calendar.getTime());
        JSpinner endDateSpinner = new JSpinner(endDateModel);
        JSpinner.DateEditor endDateEditor = new JSpinner.DateEditor(endDateSpinner, "YYYY:MM:dd");
        DateFormatter endDateFormatter = (DateFormatter) endDateEditor.getTextField().getFormatter();
        endDateFormatter.setAllowsInvalid(false); // this makes what you want
        endDateFormatter.setOverwriteMode(true);
        endDateSpinner.setEditor(endDateEditor);
        JLabel endDateLabel = new JLabel("Ending Date", JLabel.TRAILING);
        CustomPanel.header2(endDateLabel);
        endDateLabel.setLabelFor(endDateSpinner);
        c.anchor = GridBagConstraints.FIRST_LINE_START;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 2;
        add(endDateLabel, c);
        c.gridx = 1;
        c.gridy = 2;
        add(endDateSpinner, c);

        //Submit
        JButton addButton = new JButton("Get Workerversaries");
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Database.init();
                    String s_date = String.valueOf(startDateSpinner.getValue()).split(" ")[5] + "-"; //Year
                    s_date += Database.returnMonthNumber(String.valueOf(startDateSpinner.getValue()).split(" ")[1]) + "-"; //Month
                    s_date += String.valueOf(startDateSpinner.getValue()).split(" ")[2]; //Day
                    String e_date = String.valueOf(endDateSpinner.getValue()).split(" ")[5] + "-"; //Year
                    e_date += Database.returnMonthNumber(String.valueOf(endDateSpinner.getValue()).split(" ")[1]) + "-"; //Month
                    e_date += String.valueOf(endDateSpinner.getValue()).split(" ")[2]; //Day
                    //System.out.println("");
                    Database.runQuery("SELECT * FROM Volunteer WHERE Start_Date BETWEEN " + 
                            s_date + " AND DATE_ADD(\"" + 
                            e_date + "\",INTERVAL 1 DAY)");
                    Database.connection.close();
                } catch (ClassNotFoundException
                        | InstantiationException
                        | IllegalAccessException
                        | SQLException ex) {
                }

            }
        });
        c.gridwidth = 2;
        c.gridx = 0;
        c.gridy = 7;
        add(addButton, c);

        //Refresh Button
        JButton refresh = new JButton("Refresh");
        refresh.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

            }
        });
        //add(refresh);

        //Show Table
        JTextArea table = new JTextArea();
        //Database.init();
        //String data = Database.returnAllRows("Event");
        table.setText(data);
        c.gridwidth = 3;
        c.gridx = 0;
        c.gridy = 9;
        add(table, c);
    }

}
