/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package addPanels;

import art_with_a_heart.Database;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Calendar;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.text.DateFormatter;

/**
 *
 * @author Rasheed
 */
public class addStorePanel extends JPanel {

    String data;
    JTextArea table;

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        try {
            g.drawImage(ImageIO.read(new File("res/background1.jpg")), 0, 0, null);
            g.drawImage(ImageIO.read(new File("res/AwaH_Logo.png")), 0, 0, null);
        } catch (IOException ex) {
        }
    }

    public addStorePanel() throws InstantiationException, ClassNotFoundException, IllegalAccessException, SQLException {
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        //construct components
        JLabel title = new JLabel("Store");
        CustomPanel.header1(title);
        title.setSize(100, 30);
        c.anchor = GridBagConstraints.PAGE_START;
        c.gridx = 1;
        c.gridy = 0;
        add(title, c);

        //Time Spinners
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 24); // 24 == 12 PM == 00:00:00
        calendar.set(Calendar.MINUTE, 0);

        //Date
        SpinnerDateModel dateModel = new SpinnerDateModel();
        dateModel.setValue(calendar.getTime());
        JSpinner dateSpinner = new JSpinner(dateModel);
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dateSpinner, "YYYY:MM:dd");
        DateFormatter dateFormatter = (DateFormatter) dateEditor.getTextField().getFormatter();
        dateFormatter.setAllowsInvalid(false); // this makes what you want
        dateFormatter.setOverwriteMode(true);
        dateSpinner.setEditor(dateEditor);
        JLabel dateSpinnerLabel = new JLabel("Opening Date", JLabel.TRAILING);
        CustomPanel.header2(dateSpinnerLabel);
        dateSpinnerLabel.setLabelFor(dateSpinner);
        c.anchor = GridBagConstraints.FIRST_LINE_START;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 1;
        add(dateSpinnerLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 1;
        add(dateSpinner, c);

        //Start Time
        SpinnerDateModel model = new SpinnerDateModel();
        model.setValue(calendar.getTime());
        JSpinner startTime = new JSpinner(model);
        JSpinner.DateEditor startEditor = new JSpinner.DateEditor(startTime, "HH:mm");
        DateFormatter startFormatter = (DateFormatter) startEditor.getTextField().getFormatter();
        startFormatter.setAllowsInvalid(false); // this makes what you want
        startFormatter.setOverwriteMode(true);
        startTime.setEditor(startEditor);
        JLabel startTimeLabel = new JLabel("Opening Hour", JLabel.TRAILING);
        CustomPanel.header2(startTimeLabel);
        startTimeLabel.setLabelFor(startTime);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 2;
        add(startTimeLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 2;
        add(startTime, c);

        //End Time
        SpinnerDateModel model2 = new SpinnerDateModel();
        model2.setValue(calendar.getTime());
        JSpinner endTime = new JSpinner(model2);
        JSpinner.DateEditor endEditor2 = new JSpinner.DateEditor(endTime, "HH:mm");
        DateFormatter endFormatter2 = (DateFormatter) endEditor2.getTextField().getFormatter();
        endFormatter2.setAllowsInvalid(false); // this makes what you want
        endFormatter2.setOverwriteMode(true);
        endTime.setEditor(endEditor2);
        JLabel endTimeLabel = new JLabel("Closing Hour", JLabel.TRAILING);
        CustomPanel.header2(endTimeLabel);
        endTimeLabel.setLabelFor(endTime);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 3;
        add(endTimeLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 3;
        add(endTime, c);

        //Location ID
        JTextField locationID = new JTextField("Location ID");
        locationID.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                locationID.setText("");
            }
        });
        locationID.setEditable(true);
        JLabel locationIDLable = new JLabel("Location ID", JLabel.TRAILING);
        CustomPanel.header2(locationIDLable);
        locationIDLable.setLabelFor(locationID);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 4;
        add(locationIDLable, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 4;
        add(locationID, c);

        //Submit
        JButton addButton = new JButton("Add Store");
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Database.init();
                    String date = String.valueOf(dateSpinner.getValue()).split(" ")[5] + "-"; //Year
                    date += Database.returnMonthNumber(String.valueOf(dateSpinner.getValue()).split(" ")[1]) + "-"; //Month
                    date += String.valueOf(dateSpinner.getValue()).split(" ")[2]; //Day
                    String start = String.valueOf(startTime.getValue()).split(" ")[3];
                    String end = String.valueOf(endTime.getValue()).split(" ")[3];
                    String locID = locationID.getText();
                    Database.runQuery("INSERT INTO Store (Date_Of, Start_Time, End_Time, Location_Id) "
                            + "VALUES (\"" + date + "\", \""
                            + start + "\", \""
                            + end + "\", \""
                            + locID + "\");");
                } catch (ClassNotFoundException
                        | InstantiationException
                        | IllegalAccessException
                        | SQLException ex) {
                }

            }
        });
        c.gridx = 1;
        c.gridy = 5;
        c.gridwidth = 2;
        add(addButton, c);

        //Delete Entry
        JLabel deleteLabel = new JLabel("Delete Entry", JLabel.TRAILING);
        CustomPanel.header2(deleteLabel);
        JTextField deleteField = new JTextField("Row ID");
        deleteLabel.setLabelFor(deleteField);
        JButton deleteButton = new JButton("Delete");
        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Database.init();
                    String A_Id = deleteField.getText();
                    Database.runQuery("DELETE FROM Store WHERE S_Id = "
                            + A_Id + ";");
                } catch (ClassNotFoundException
                        | InstantiationException
                        | IllegalAccessException
                        | SQLException ex) {
                }

            }
        });
        c.gridx = 0;
        c.gridy = 6;
        c.gridwidth = 1;
        add(deleteLabel, c);
        c.gridx = 1;
        c.gridy = 6;
        add(deleteField, c);
        c.gridx = 2;
        c.gridy = 6;
        add(deleteButton, c);

        //Refresh
        JButton refreshTable = new JButton("Refresh Table");
        refreshTable.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Database.init();
                    setData(Database.returnAllRows(data));
                    table.setText(data);
                    add(table, c);
                    //Database.connection.close();
                } catch (ClassNotFoundException
                        | InstantiationException
                        | IllegalAccessException
                        | SQLException ex) {
                }

            }
        });
        c.gridx = 1;
        c.gridy = 7;
        //add(refreshTable, c);

        //Show Table
        Database.init();
        data = Database.returnAllRows("Store");
        table = new JTextArea();
        table.setEditable(false);
        table.setText(data);
        c.gridwidth = 3;
        c.gridx = 0;
        c.gridy = 8;
        add(table, c);
    }

    public void setData(String data) {
        this.data = data;
    }
}
