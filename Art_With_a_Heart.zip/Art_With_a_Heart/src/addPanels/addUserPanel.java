/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package addPanels;

import art_with_a_heart.Database;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Calendar;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.text.DateFormatter;

/**
 *
 * @author Rasheed
 */
public class addUserPanel extends JPanel {

    String data;
    JTextArea table;

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        try {
            g.drawImage(ImageIO.read(new File("res/background1.jpg")), 0, 0, null);
            g.drawImage(ImageIO.read(new File("res/AwaH_Logo.png")), 0, 0, null);
        } catch (IOException ex) {
        }
    }

    public addUserPanel() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        //construct components
        JLabel title = new JLabel("User");
        title.setSize(100, 30);
        CustomPanel.header1(title);
        c.anchor = GridBagConstraints.PAGE_START;
        c.gridx = 1;
        c.gridy = 0;
        add(title, c);

        //First Name
        JTextField Fname = new JTextField("First Name");
        Fname.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Fname.setText("");
            }
        });
        Fname.setEditable(true);
        JLabel FnameLabel = new JLabel("First Name", JLabel.TRAILING);
        CustomPanel.header2(FnameLabel);
        FnameLabel.setLabelFor(Fname);
        c.anchor = GridBagConstraints.FIRST_LINE_START;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 1;
        add(FnameLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 1;
        add(Fname, c);

        //Middle init
        JTextField middleInit = new JTextField("M");
        middleInit.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                middleInit.setText("");
            }
        });
        middleInit.setEditable(true);
        JLabel middleInitLabel = new JLabel("Middle Init", JLabel.TRAILING);
        CustomPanel.header2(middleInitLabel);
        middleInitLabel.setLabelFor(middleInit);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 2;
        add(middleInitLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 2;
        add(middleInit, c);

        //Last Name
        JTextField Lname = new JTextField("Last Name");
        Lname.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Lname.setText("");
            }
        });
        Lname.setEditable(true);
        JLabel LnameLabel = new JLabel("Last Name", JLabel.TRAILING);
        CustomPanel.header2(LnameLabel);
        LnameLabel.setLabelFor(Lname);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 3;
        add(LnameLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 3;
        add(Lname, c);

        //Time Spinners
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 24); // 24 == 12 PM == 00:00:00
        calendar.set(Calendar.MINUTE, 0);

        //Date
        SpinnerDateModel dateModel = new SpinnerDateModel();
        dateModel.setValue(calendar.getTime());
        JSpinner dateSpinner = new JSpinner(dateModel);
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dateSpinner, "YYYY:MM:dd");
        DateFormatter dateFormatter = (DateFormatter) dateEditor.getTextField().getFormatter();
        dateFormatter.setAllowsInvalid(false); // this makes what you want
        dateFormatter.setOverwriteMode(true);
        dateSpinner.setEditor(dateEditor);
        JLabel dateSpinnerLabel = new JLabel("Date", JLabel.TRAILING);
        CustomPanel.header2(dateSpinnerLabel);
        dateSpinnerLabel.setLabelFor(dateSpinner);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 4;
        add(dateSpinnerLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 4;
        add(dateSpinner, c);

        //email
        JTextField email = new JTextField("Email");
        email.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                email.setText("");
            }
        });
        email.setEditable(true);
        JLabel emailLabel = new JLabel("Email", JLabel.TRAILING);
        CustomPanel.header2(emailLabel);
        emailLabel.setLabelFor(email);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 5;
        add(emailLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 5;
        add(email, c);

        //phoneNum
        JTextField phoneNum = new JTextField("Phone Number");
        phoneNum.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                phoneNum.setText("");
            }
        });
        phoneNum.setEditable(true);
        JLabel phoneNumLabel = new JLabel("Phone Number", JLabel.TRAILING);
        CustomPanel.header2(phoneNumLabel);
        phoneNumLabel.setLabelFor(phoneNum);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 6;
        add(phoneNumLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 6;
        add(phoneNum, c);

        //usertype
        JTextField usertype = new JTextField("User Type");
        usertype.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                usertype.setText("");
            }
        });
        usertype.setEditable(true);
        JLabel usertypeLabel = new JLabel("User Type", JLabel.TRAILING);
        CustomPanel.header2(usertypeLabel);
        usertypeLabel.setLabelFor(usertype);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 7;
        add(usertypeLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 7;
        add(usertype, c);

        //username
        JTextField username = new JTextField("Username");
        username.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                username.setText("");
            }
        });
        username.setEditable(true);
        JLabel usernameLabel = new JLabel("Username", JLabel.TRAILING);
        CustomPanel.header2(usernameLabel);
        usernameLabel.setLabelFor(usertype);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 8;
        add(usernameLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 8;
        add(username, c);

        //password
        JTextField password = new JTextField("Password");
        password.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                password.setText("");
            }
        });
        password.setEditable(true);
        JLabel passwordLabel = new JLabel("Password", JLabel.TRAILING);
        CustomPanel.header2(passwordLabel);
        passwordLabel.setLabelFor(password);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 9;
        add(passwordLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 9;
        add(password, c);

        //Submit
        JButton addButton = new JButton("Add User");
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Database.init();
                    String Fname_s = Fname.getText();
                    String middleInit_s = middleInit.getText();
                    String Lname_s = Lname.getText();
                    String DOB = String.valueOf(dateSpinner.getValue()).split(" ")[5] + "-"; //Year
                    DOB += Database.returnMonthNumber(String.valueOf(dateSpinner.getValue()).split(" ")[1]) + "-"; //Month
                    DOB += String.valueOf(dateSpinner.getValue()).split(" ")[2]; //Day
                    String email_s = email.getText();
                    String phoneNum_s = phoneNum.getText();
                    String usertype_s = usertype.getText();
                    String username_s = username.getText();
                    String password_s = password.getText();
                    Database.runQuery("INSERT INTO User (Fname, Minit, Lname, DOB, Email, Phone_Num, User_Type, User_Name, Password) "
                            + "VALUES (\"" + Fname_s + "\", \""
                            + middleInit_s + "\", \""
                            + Lname_s + "\", \""
                            + DOB + "\", \""
                            + email_s + "\", \""
                            + phoneNum_s + "\", \""
                            + usertype_s + "\", \""
                            + username_s + "\", \""
                            + password_s + "\");");
                } catch (ClassNotFoundException
                        | InstantiationException
                        | IllegalAccessException
                        | SQLException ex) {
                }

            }
        });
        c.gridx = 1;
        c.gridy = 10;
        c.gridwidth = 2;
        add(addButton, c);

        //Delete Entry
        JLabel deleteLabel = new JLabel("Delete Entry", JLabel.TRAILING);
        CustomPanel.header2(deleteLabel);
        JTextField deleteField = new JTextField("Row ID");
        deleteLabel.setLabelFor(deleteField);
        JButton deleteButton = new JButton("Delete");
        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Database.init();
                    String A_Id = deleteField.getText();
                    Database.runQuery("DELETE FROM User WHERE U_Id = "
                            + A_Id + ";");
                } catch (ClassNotFoundException
                        | InstantiationException
                        | IllegalAccessException
                        | SQLException ex) {
                }

            }
        });
        c.gridx = 0;
        c.gridy = 11;
        c.gridwidth = 1;
        add(deleteLabel, c);
        c.gridx = 1;
        c.gridy = 11;
        add(deleteField, c);
        c.gridx = 2;
        c.gridy = 11;
        add(deleteButton, c);

        //Refresh
        JButton refreshTable = new JButton("Refresh Table");
        refreshTable.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Database.init();
                    setData(Database.returnAllRows(data));
                    table.setText(data);
                    add(table, c);
                    //Database.connection.close();
                } catch (ClassNotFoundException
                        | InstantiationException
                        | IllegalAccessException
                        | SQLException ex) {
                }

            }
        });
        c.gridx = 1;
        c.gridy = 12;
        //add(refreshTable, c);

        //Show Table
        Database.init();
        data = Database.returnAllRows("Users");
        table = new JTextArea();
        table.setEditable(false);
        table.setText(data);
        c.gridwidth = 3;
        c.gridx = 0;
        c.gridy = 13;
        add(table, c);
    }

    public void setData(String data) {
        this.data = data;
    }
}
