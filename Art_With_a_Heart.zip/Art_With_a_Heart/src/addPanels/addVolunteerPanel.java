/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package addPanels;

import art_with_a_heart.Database;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Calendar;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.text.DateFormatter;

/**
 *
 * @author Rasheed
 */
public class addVolunteerPanel extends JPanel {

    String data;
    JTextArea table;

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        try {
            g.drawImage(ImageIO.read(new File("res/background1.jpg")), 0, 0, null);
            g.drawImage(ImageIO.read(new File("res/AwaH_Logo.png")), 0, 0, null);
        } catch (IOException ex) {
        }
    }

    public addVolunteerPanel() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        setOpaque(true);
        //construct components
        JLabel title = new JLabel("Volunteers");
        CustomPanel.header1(title);
        title.setSize(100, 30);
        c.anchor = GridBagConstraints.PAGE_START;
        c.gridx = 1;
        c.gridy = 0;
        add(title, c);

        //Time Spinners
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 24); // 24 == 12 PM == 00:00:00
        calendar.set(Calendar.MINUTE, 0);

        //Date
        SpinnerDateModel dateModel = new SpinnerDateModel();
        dateModel.setValue(calendar.getTime());
        JSpinner dateSpinner = new JSpinner(dateModel);
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dateSpinner, "YYYY:MM:dd");
        DateFormatter dateFormatter = (DateFormatter) dateEditor.getTextField().getFormatter();
        dateFormatter.setAllowsInvalid(false); // this makes what you want
        dateFormatter.setOverwriteMode(true);
        dateSpinner.setEditor(dateEditor);
        JLabel dateLabel = new JLabel("Date of Hire", JLabel.TRAILING);
        CustomPanel.header2(dateLabel);
        dateLabel.setLabelFor(dateSpinner);
        c.anchor = GridBagConstraints.FIRST_LINE_START;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 1;
        add(dateLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 1;
        add(dateSpinner, c);

        //specialSkill
        JTextField specialSkill = new JTextField("Special Skill");
        specialSkill.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                specialSkill.setText("");
            }
        });
        specialSkill.setEditable(true);
        JLabel specialSkillLabel = new JLabel("Special Skill", JLabel.TRAILING);
        CustomPanel.header2(specialSkillLabel);
        specialSkillLabel.setLabelFor(specialSkill);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 2;
        add(specialSkillLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 2;
        add(specialSkill, c);

        //media
        JTextField media = new JTextField("Media");
        media.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                media.setText("");
            }
        });
        media.setEditable(true);
        JLabel mediaLabel = new JLabel("Media", JLabel.TRAILING);
        CustomPanel.header2(mediaLabel);
        mediaLabel.setLabelFor(media);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 3;
        add(mediaLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 3;
        add(media, c);

        //User_Id
        JTextField User_Id = new JTextField("User Id");
        User_Id.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                User_Id.setText("");
            }
        });
        User_Id.setEditable(true);
        JLabel User_IdLabel = new JLabel("User Id", JLabel.TRAILING);
        CustomPanel.header2(User_IdLabel);
        User_IdLabel.setLabelFor(User_Id);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 4;
        add(User_IdLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 4;
        add(User_Id, c);

        //Vol_G_Id
        JTextField Vol_G_Id = new JTextField("Vol_G_Id");
        Vol_G_Id.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Vol_G_Id.setText("");
            }
        });
        Vol_G_Id.setEditable(true);
        JLabel Vol_G_IdLabel = new JLabel("Vol_G_Id", JLabel.TRAILING);
        CustomPanel.header2(Vol_G_IdLabel);
        Vol_G_IdLabel.setLabelFor(Vol_G_Id);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 5;
        add(Vol_G_IdLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 5;
        add(Vol_G_Id, c);

        //Submit
        JButton addButton = new JButton("Add Volunteer");
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Database.init();
                    String Start_Date_s = String.valueOf(dateSpinner.getValue()).split(" ")[5] + "-"; //Year
                    Start_Date_s += Database.returnMonthNumber(String.valueOf(dateSpinner.getValue()).split(" ")[1]) + "-"; //Month
                    Start_Date_s += String.valueOf(dateSpinner.getValue()).split(" ")[2]; //Day
                    String specialSkill_s = specialSkill.getText();
                    String media_s = media.getText();
                    String User_Id_s = User_Id.getText();
                    String Vol_G_Id_s = Vol_G_Id.getText();
                    Database.runQuery("INSERT INTO Volunteer (Start_Date, Special_Skill, Media, User_Id, Vol_G_Id) "
                            + "VALUES (\"" + Start_Date_s + "\", \""
                            + specialSkill_s + "\", \""
                            + media_s + "\", \""
                            + User_Id_s + "\", \""
                            + Vol_G_Id_s + "\");");
                    Database.connection.close();
                } catch (ClassNotFoundException
                        | InstantiationException
                        | IllegalAccessException
                        | SQLException ex) {
                }

            }
        });
        c.gridx = 1;
        c.gridy = 6;
        c.gridwidth = 2;
        add(addButton, c);

        //Delete Entry
        JLabel deleteLabel = new JLabel("Delete Entry", JLabel.TRAILING);
        CustomPanel.header2(deleteLabel);
        JTextField deleteField = new JTextField("Row ID");
        deleteLabel.setLabelFor(deleteField);
        JButton deleteButton = new JButton("Delete");
        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Database.init();
                    String A_Id = deleteField.getText();
                    Database.runQuery("DELETE FROM Volunteer WHERE V_Id = "
                            + A_Id + ";");
                } catch (ClassNotFoundException
                        | InstantiationException
                        | IllegalAccessException
                        | SQLException ex) {
                }

            }
        });
        c.gridx = 0;
        c.gridy = 7;
        c.gridwidth = 1;
        add(deleteLabel, c);
        c.gridx = 1;
        c.gridy = 7;
        add(deleteField, c);
        c.gridx = 2;
        c.gridy = 7;
        add(deleteButton, c);

        //Refresh
        JButton refreshTable = new JButton("Refresh Table");
        refreshTable.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Database.init();
                    setData(Database.returnAllRows(data));
                    table.setText(data);
                    add(table, c);
                    //Database.connection.close();
                } catch (ClassNotFoundException
                        | InstantiationException
                        | IllegalAccessException
                        | SQLException ex) {
                }

            }
        });
        c.gridx = 1;
        c.gridy = 8;
        //add(refreshTable, c);

        //Show Table
        Database.init();
        data = Database.returnAllRows("Volunteer");
        table = new JTextArea();
        table.setEditable(false);
        table.setText(data);
        c.gridwidth = 3;
        c.gridx = 0;
        c.gridy = 9;
        add(table, c);
    }

    public void setData(String data) {
        this.data = data;
    }

}
