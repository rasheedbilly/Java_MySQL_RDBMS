/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package addPanels;

import art_with_a_heart.Database;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Calendar;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.text.DateFormatter;

/**
 *
 * @author Rasheed
 */
public class addAvailabilityPanel extends JPanel {

    String data;
    JTextArea table;

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        try {
            g.drawImage(ImageIO.read(new File("res/background1.jpg")), 0, 0, null);
            g.drawImage(ImageIO.read(new File("res/AwaH_Logo.png")), 0, 0, null);
        } catch (IOException ex) {
        }
    }

    public addAvailabilityPanel() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        //construct components
        JLabel title = new JLabel("Availability");
        CustomPanel.header1(title);
        c.anchor = GridBagConstraints.PAGE_START;
        c.gridx = 1;
        c.gridy = 0;
        add(title, c);

        //Weekday
        JLabel weekdayLabel = new JLabel("Weekday", JLabel.TRAILING);
        CustomPanel.header2(weekdayLabel);
        String[] w = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
        JComboBox weekday = new JComboBox(w);
        weekdayLabel.setLabelFor(weekday);
        weekday.setEditable(true);
        //c.fill = GridBagConstraints.VERTICAL;
        c.anchor = GridBagConstraints.FIRST_LINE_START;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 1;
        add(weekdayLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 1;
        add(weekday, c);

        //Time Spinners
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY,24); // 24 == 12 PM == 00:00:00
        calendar.set(Calendar.MINUTE,0);
        //DateFormat df = new SimpleDateFormat("HH:mm");

        //Start Time
        JLabel startTimeLabel = new JLabel("Start Time", JLabel.TRAILING);
        CustomPanel.header2(startTimeLabel);
        SpinnerDateModel model = new SpinnerDateModel();
        model.setValue(calendar.getTime());
        JSpinner startTime = new JSpinner(model);
        JSpinner.DateEditor startEditor = new JSpinner.DateEditor(startTime, "HH:mm");
        DateFormatter startFormatter = (DateFormatter) startEditor.getTextField().getFormatter();
        startFormatter.setAllowsInvalid(false); // this makes what you want
        startFormatter.setOverwriteMode(true);
        startTime.setEditor(startEditor);
        startTimeLabel.setLabelFor(startTime);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 2;
        add(startTimeLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 2;
        add(startTime, c);

        //End Time
        JLabel endTimeLabel = new JLabel("End Time", JLabel.TRAILING);
        CustomPanel.header2(endTimeLabel);
        SpinnerDateModel model2 = new SpinnerDateModel();
        model2.setValue(calendar.getTime());
        JSpinner endTime = new JSpinner(model2);
        JSpinner.DateEditor endEditor2 = new JSpinner.DateEditor(endTime, "HH:mm");
        DateFormatter endFormatter2 = (DateFormatter) endEditor2.getTextField().getFormatter();
        endFormatter2.setAllowsInvalid(false); // this makes what you want
        endFormatter2.setOverwriteMode(true);
        endTime.setEditor(endEditor2);
        endTimeLabel.setLabelFor(endTime);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 3;
        add(endTimeLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 3;
        add(endTime, c);
        //Volunteer ID
        JLabel volIDLabel = new JLabel("Volunteer ID", JLabel.TRAILING);
        CustomPanel.header2(volIDLabel);
        JTextField volunteerID = new JTextField("volunteerID");
        volunteerID.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                volunteerID.setText("");
            }
        });
        volunteerID.setEditable(true);
        volIDLabel.setLabelFor(volunteerID);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 4;
        add(volIDLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 4;

        add(volunteerID, c);

        //Submit
        JButton addButton = new JButton("Add Availability");
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Database.init();
                    String wd = weekday.getSelectedItem().toString();
                    String start = String.valueOf(startTime.getValue()).split(" ")[3];
                    String end = String.valueOf(endTime.getValue()).split(" ")[3];
                    String volID = volunteerID.getText();
                    Database.runQuery("INSERT INTO Availability (Day, Start_Time, End_Time, Volunteer_Id) "
                            + "VALUES (\"" + wd + "\", \""
                            + start + "\", \""
                            + end + "\", \""
                            + volID + "\");");
                    Database.connection.close();
                } catch (ClassNotFoundException
                        | InstantiationException
                        | IllegalAccessException
                        | SQLException ex) {
                }

            }
        }
        );
        c.gridx = 1;
        c.gridy = 5;
        add(addButton, c);

        //Delete Entry
        JLabel deleteLabel = new JLabel("Delete Entry", JLabel.TRAILING);
        CustomPanel.header2(deleteLabel);
        JTextField deleteField = new JTextField("Row ID");
        deleteLabel.setLabelFor(deleteField);
        JButton deleteButton = new JButton("Delete");
        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Database.init();
                    String A_Id = deleteField.getText();
                    Database.runQuery("DELETE FROM Availability WHERE A_Id = "
                            + A_Id + ";");
                } catch (ClassNotFoundException
                        | InstantiationException
                        | IllegalAccessException
                        | SQLException ex) {
                }

            }
        });
        c.gridx = 0;
        c.gridy = 6;
        c.gridwidth = 1;
        add(deleteLabel, c);
        c.gridx = 1;
        c.gridy = 6;
        add(deleteField, c);
        c.gridx = 2;
        c.gridy = 6;
        add(deleteButton, c);

        //Refresh
        JButton refreshTable = new JButton("Refresh Table");
        refreshTable.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Database.init();
                    setData(Database.returnAllRows(data));
                    table.setText(data);
                    add(table, c);
                    //Database.connection.close();
                } catch (ClassNotFoundException
                        | InstantiationException
                        | IllegalAccessException
                        | SQLException ex) {
                }

            }
        });
        c.gridx = 1;
        c.gridy = 5;
        //add(refreshTable, c);

        //Show Table
        Database.init();
        data = Database.returnAllRows("Availability");
        table = new JTextArea();
        table.setEditable(false);
        table.setText(data);
        c.gridwidth = 3;
        c.gridx = 0;
        c.gridy = 7;
        add(table, c);

        //Database.connection.close();
    }

//    @Override
//    public Dimension getPreferredSize() {
//        return (new Dimension(300, 500));
//    }
    public void setData(String data) {
        this.data = data;
    }
}
