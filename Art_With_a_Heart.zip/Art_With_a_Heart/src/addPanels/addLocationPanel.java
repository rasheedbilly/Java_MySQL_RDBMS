/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package addPanels;

import art_with_a_heart.Database;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author Rasheed
 */
public class addLocationPanel extends JPanel {
    
    String data;
    JTextArea table;

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        try {
            g.drawImage(ImageIO.read(new File("res/background1.jpg")), 0, 0, null);
            g.drawImage(ImageIO.read(new File("res/AwaH_Logo.png")), 0, 0, null);
        } catch (IOException ex) {
        }
    }

    public addLocationPanel() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        //construct components
        JLabel title = new JLabel("Location");
        CustomPanel.header1(title);
        title.setSize(100, 30);
        c.anchor = GridBagConstraints.PAGE_START;
        c.gridx = 1;
        c.gridy = 0;
        add(title, c);

        //Last Name
        JTextField Lname = new JTextField("Last Name", 20);
        Lname.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Lname.setText("");
            }
        });
        Lname.setEditable(true);
        JLabel LNameLabel = new JLabel("Last Name", JLabel.TRAILING);
        CustomPanel.header2(LNameLabel);
        LNameLabel.setLabelFor(Lname);
        c.anchor = GridBagConstraints.FIRST_LINE_START;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 1;
        add(LNameLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 1;
        add(Lname, c);

        //Addr_Line_1
        JTextField Addr_Line_1 = new JTextField("Addr_Line_1");
        Addr_Line_1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Addr_Line_1.setText("");
            }
        });
        Addr_Line_1.setEditable(true);
        JLabel Addr1Label = new JLabel("Address Line 1", JLabel.TRAILING);
        CustomPanel.header2(Addr1Label);
        Addr1Label.setLabelFor(Addr_Line_1);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 2;
        add(Addr1Label, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 2;
        add(Addr_Line_1, c);

        //Addr_Line_2
        JTextField Addr_Line_2 = new JTextField("Addr_Line_1");
        Addr_Line_2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Addr_Line_2.setText("");
            }
        });
        Addr_Line_2.setEditable(true);
        JLabel Addr2Label = new JLabel("Address Line 2", JLabel.TRAILING);
        CustomPanel.header2(Addr2Label);
        Addr2Label.setLabelFor(Addr_Line_2);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 3;
        add(Addr2Label, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 3;
        add(Addr_Line_2, c);

        //City
        JTextField city = new JTextField("City");
        city.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                city.setText("");
            }
        });
        city.setEditable(true);
        JLabel cityLabel = new JLabel("City", JLabel.TRAILING);
        CustomPanel.header2(cityLabel);
        cityLabel.setLabelFor(city);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 4;
        add(cityLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 4;
        add(city, c);

        //State
        JTextField state = new JTextField("State");
        state.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                state.setText("");
            }
        });
        state.setEditable(true);
        JLabel stateLabel = new JLabel("State", JLabel.TRAILING);
        CustomPanel.header2(stateLabel);
        stateLabel.setLabelFor(state);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 5;
        add(stateLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 5;
        add(state, c);

        //zipCode
        JTextField zipCode = new JTextField("zipCode");
        zipCode.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                zipCode.setText("");
            }
        });
        zipCode.setEditable(true);
        JLabel zipLabel = new JLabel("Zip Code", JLabel.TRAILING);
        CustomPanel.header2(zipLabel);
        zipLabel.setLabelFor(zipCode);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 6;
        add(zipLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 6;
        add(zipCode, c);

        //locationType
        JTextField locationType = new JTextField("locationType");
        locationType.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                locationType.setText("");
            }
        });
        locationType.setEditable(true);
        JLabel locationLabel = new JLabel("Location", JLabel.TRAILING);
        CustomPanel.header2(locationLabel);
        locationLabel.setLabelFor(locationType);
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 7;
        add(locationLabel, c);
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 7;
        add(locationType, c);

        //Submit
        JButton addButton = new JButton("Add Location");
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Database.init();
                    String sLName = Lname.getText();
                    String sAddr_Line_1 = Addr_Line_1.getText();
                    String sAddr_Line_2 = Addr_Line_2.getText();
                    String sCity = city.getText();
                    String sState = state.getText();
                    String sZip_Code = zipCode.getText();
                    String sLocType = locationType.getText();
                    Database.runQuery("INSERT INTO Availability (LName, Addr_Line_1, Addr_Line_2, City, State, Zip_Code, LocType) "
                            + "VALUES (\"" + sLName + "\", \""
                            + sAddr_Line_1 + "\", \""
                            + sAddr_Line_2 + "\", \""
                            + sCity + "\", \""
                            + sState + "\", \""
                            + sZip_Code + "\", \""
                            + sLocType + "\");");
                    Database.connection.close();
                } catch (ClassNotFoundException
                        | InstantiationException
                        | IllegalAccessException
                        | SQLException ex) {
                }

            }
        });
        c.gridx = 1;
        c.gridy = 8;
        c.gridwidth = 2;
        add(addButton, c);

        //Delete Entry
        JLabel deleteLabel = new JLabel("Delete Entry", JLabel.TRAILING);
        CustomPanel.header2(deleteLabel);
        JTextField deleteField = new JTextField("Row ID");
        deleteLabel.setLabelFor(deleteField);
        JButton deleteButton = new JButton("Delete");
        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Database.init();
                    String A_Id = deleteField.getText();
                    Database.runQuery("DELETE FROM Location WHERE L_Id = "
                            + A_Id + ";");
                } catch (ClassNotFoundException
                        | InstantiationException
                        | IllegalAccessException
                        | SQLException ex) {
                }

            }
        });
        c.gridx = 0;
        c.gridy = 9;
        c.gridwidth = 1;
        add(deleteLabel, c);
        c.gridx = 1;
        c.gridy = 9;
        add(deleteField, c);
        c.gridx = 2;
        c.gridy = 9;
        add(deleteButton, c);

        //Refresh
        JButton refreshTable = new JButton("Refresh Table");
        refreshTable.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Database.init();
                    setData(Database.returnAllRows(data));
                    table.setText(data);
                    add(table, c);
                    //Database.connection.close();
                } catch (ClassNotFoundException
                        | InstantiationException
                        | IllegalAccessException
                        | SQLException ex) {
                }

            }
        });
        c.gridx = 1;
        c.gridy = 10;
        //add(refreshTable, c);

        //Show Table
        Database.init();
        data = Database.returnAllRows("Location");
        table = new JTextArea();
        table.setEditable(false);
        table.setText(data);
        c.gridwidth = 3;
        c.gridx = 0;
        c.gridy = 11;
        add(table, c);
    }
    public void setData(String data) {
        this.data = data;
    }

}
